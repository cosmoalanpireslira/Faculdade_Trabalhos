<?php

$servidor = "localhost";
$dbusuario = "root";
$dbsenha = "";
$dbname = "cadastro1db";

//conexao com mysql

$conn = mysqli_connect($servidor, $dbusuario, $dbsenha, $dbname);
?>