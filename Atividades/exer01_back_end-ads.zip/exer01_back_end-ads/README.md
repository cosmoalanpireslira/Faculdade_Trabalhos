<h2>Exercicio 02 - Back End</h2>

Todos as questões fazem referências a questões do BeeCrowd
1. (1013) The Greatest
2. (1018) Banknotes
3. (1133) Rest of a Division
4. (1101) Sequence of Numbers and Sum
5. (1789) The Race of Slugs
6. (1071) Sum of Consecutive Odd Numbers I
7. (1103) Alarm Clock
8. (1024) Encryption
9. (1168) LED
10. (1253) Caesar Cipher
11. (1259) Even and Odd
12. (1028) Collectable Cards
