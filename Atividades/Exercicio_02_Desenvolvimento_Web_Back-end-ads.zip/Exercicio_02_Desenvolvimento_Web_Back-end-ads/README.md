# Exercicio_02_Desenvolvimento_Web_Back-end
Exercício 02 - Desenvolvimento Web Back-end
Todos as questões fazem referências a questões do BeeCrowd
1. (1036) Fórmula de Bhaskara
2. (1171) Frequência de Números
3. (1329) Cara ou Coroa
4. (1471) Mergulho
5. (1987) Divisibilidade por 3
6. (2164) Fibonacci Rápido
7. (2473) Loteria
8. (2588) Jogo dos Palíndromos
9. (2866) Criptotexto
10. (1536) Libertadores
11. (1029) Fibonacci, Quantas Chamadas?
12. (1258) Camisetas
13. (1542) Lendo Livros
14. (2399) Campo Minado
