# TDE2.php
Sistema de faculdade em PHP
