<?php
class Professor{
  public $nome;
  public $disciplina;

  public function exibirProfessor(){
    echo "\nProfessor: ".$this->nome. "\nDisciplina: ".$this->disciplina;

  }

}
