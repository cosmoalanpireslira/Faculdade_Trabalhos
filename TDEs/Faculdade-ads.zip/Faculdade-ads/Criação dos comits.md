Certifique-se de instalar o PHPUnit em seu ambiente de desenvolvimento e, em seguida, execute os testes executando o comando phpunit NomeDoArquivoTest.php no terminal, onde NomeDoArquivoTest.php é o nome do arquivo que contém os testes unitários.




