<!DOCTYPE html>
<html>
<head>
    <title>Sistema de Faculdade</title>
</head>
<body>
    <h1>Login do Aluno</h1>
    <form method="POST" action="login.php">
        <label for="matricula">Matrícula:</label>
        <input type="text" name="matricula" id="matricula" required>
        <br><br>
        <label for="senha">Senha:</label>
        <input type="password" name="senha" id="senha" required>
        <br><br>
        <input type="submit" value="Entrar">
    </form>
</body>
</html>


